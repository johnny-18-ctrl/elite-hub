import { SurveysListing } from "@/components/survey/surveys-listing";

export default function Home() {
  return <SurveysListing />;
}
