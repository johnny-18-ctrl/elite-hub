import { surveys, surveyQuestions } from "@/lib/surveys";
import { notFound } from "next/navigation";
import { SurveyContainer } from "@/components/survey/survey-container";

interface SurveyPageProps {
  params: Promise<{ id: string }>;
}

export default async function SurveyPage({ params }: SurveyPageProps) {
  const { id } = await params;
  const survey = surveys.find((s) => s.id === id);
  const questions = surveyQuestions[id];

  if (!survey || !questions) {
    notFound();
  }

  return <SurveyContainer survey={survey} questions={questions} />;
}
