"use client";

import { useState } from "react";
import { Gift, Lock, DollarSign, CheckCircle2, ArrowRight, Wallet, Shield, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type Step = "reward" | "activate" | "processing" | "success";

export default function RewardPage() {
  const [step, setStep] = useState<Step>("reward");
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null);

  const handleClaimReward = () => {
    setStep("activate");
  };

  const handleActivate = () => {
    setStep("processing");
    setTimeout(() => {
      setStep("success");
    }, 2000);
  };

  if (step === "processing") {
    return (
      <main className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center space-y-6">
          <div className="w-16 h-16 mx-auto rounded-full border-4 border-primary border-t-transparent animate-spin" />
          <p className="text-lg text-muted-foreground">Processing your activation...</p>
        </div>
      </main>
    );
  }

  if (step === "success") {
    return (
      <main className="min-h-screen flex items-center justify-center p-6">
        <div className="max-w-md text-center space-y-6">
          <div className="w-20 h-20 mx-auto rounded-full bg-green-100 flex items-center justify-center">
            <CheckCircle2 className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="font-serif text-4xl text-foreground">Account Activated!</h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Your account is now active. Your $10 reward will be processed within 24-48 hours.
          </p>
          <Card className="bg-secondary/50 border-0">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between text-lg">
                <span className="text-muted-foreground">Reward Balance</span>
                <span className="font-semibold text-green-600">$10.00</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    );
  }

  if (step === "activate") {
    return (
      <main className="min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-lg space-y-8">
          <div className="text-center space-y-3">
            <div className="w-16 h-16 mx-auto rounded-full bg-accent/10 flex items-center justify-center">
              <Shield className="w-8 h-8 text-accent" />
            </div>
            <h1 className="font-serif text-3xl md:text-4xl text-foreground">Activate Your Account</h1>
            <p className="text-muted-foreground leading-relaxed">
              A one-time activation fee of <span className="font-semibold text-foreground">$3.00</span> is required to verify your account and process withdrawals.
            </p>
          </div>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="text-lg">Payment Details</CardTitle>
              <CardDescription>Select your preferred payment method</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Payment Method Selection */}
              <div className="grid grid-cols-2 gap-3">
                {["Credit Card", "PayPal"].map((method) => (
                  <button
                    key={method}
                    onClick={() => setPaymentMethod(method)}
                    className={`p-4 rounded-lg border-2 transition-all duration-200 text-left
                      ${paymentMethod === method 
                        ? "border-primary bg-primary/5" 
                        : "border-border hover:border-primary/50"
                      }`}
                  >
                    <span className="font-medium">{method}</span>
                  </button>
                ))}
              </div>

              {paymentMethod === "Credit Card" && (
                <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="space-y-2">
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input id="cardNumber" placeholder="1234 5678 9012 3456" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiry">Expiry Date</Label>
                      <Input id="expiry" placeholder="MM/YY" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cvv">CVV</Label>
                      <Input id="cvv" placeholder="123" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="name">Cardholder Name</Label>
                    <Input id="name" placeholder="John Doe" />
                  </div>
                </div>
              )}

              {paymentMethod === "PayPal" && (
                <div className="p-4 bg-secondary rounded-lg text-center animate-in fade-in slide-in-from-top-2 duration-200">
                  <p className="text-muted-foreground">You will be redirected to PayPal to complete the payment.</p>
                </div>
              )}

              {/* Summary */}
              <div className="pt-4 border-t border-border space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Activation Fee</span>
                  <span>$3.00</span>
                </div>
                <div className="flex justify-between font-semibold text-lg">
                  <span>Total</span>
                  <span>$3.00</span>
                </div>
              </div>

              <Button 
                onClick={handleActivate} 
                disabled={!paymentMethod}
                className="w-full gap-2"
                size="lg"
              >
                <Lock className="w-4 h-4" />
                Pay $3.00 & Activate
              </Button>

              <p className="text-xs text-center text-muted-foreground">
                Secure payment processed with 256-bit encryption
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
    );
  }

  // Initial reward reveal step
  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-lg space-y-8">
        <div className="text-center space-y-4">
          <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-amber-100 to-amber-200 flex items-center justify-center shadow-lg">
            <Gift className="w-12 h-12 text-amber-600" />
          </div>
          <div className="space-y-2">
            <p className="text-sm font-medium text-accent uppercase tracking-wide">Congratulations!</p>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground">You&apos;ve Earned</h1>
          </div>
        </div>

        <Card className="border-0 bg-gradient-to-br from-primary/5 to-accent/5 shadow-xl">
          <CardContent className="pt-8 pb-8">
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center gap-2">
                <DollarSign className="w-12 h-12 text-green-600" />
                <span className="font-serif text-7xl md:text-8xl font-bold text-foreground">10</span>
              </div>
              <p className="text-lg text-muted-foreground">
                Thank you for completing our survey!
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Button onClick={handleClaimReward} size="lg" className="w-full gap-2 h-14 text-lg">
            <Wallet className="w-5 h-5" />
            Claim Your Reward
            <ArrowRight className="w-5 h-5" />
          </Button>

          <div className="flex items-start gap-3 p-4 bg-secondary/50 rounded-lg">
            <Sparkles className="w-5 h-5 text-accent mt-0.5 shrink-0" />
            <p className="text-sm text-muted-foreground">
              Your reward is ready to be claimed. Complete a quick account activation to withdraw your earnings.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}
