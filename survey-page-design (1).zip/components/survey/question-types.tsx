"use client";

import { Check } from "lucide-react";

interface MultipleChoiceProps {
  options: string[];
  value: string | null;
  onChange: (value: string) => void;
}

export function MultipleChoice({ options, value, onChange }: MultipleChoiceProps) {
  return (
    <div className="space-y-3">
      {options.map((option, index) => (
        <button
          key={option}
          onClick={() => onChange(option)}
          className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all duration-200 text-left group
            ${value === option 
              ? "border-primary bg-primary/5" 
              : "border-border hover:border-primary/50 hover:bg-secondary/50"
            }`}
        >
          <span className={`flex items-center justify-center w-8 h-8 rounded-lg text-sm font-medium transition-colors
            ${value === option 
              ? "bg-primary text-primary-foreground" 
              : "bg-secondary text-muted-foreground group-hover:bg-primary/10"
            }`}>
            {String.fromCharCode(65 + index)}
          </span>
          <span className="flex-1 text-foreground font-medium">{option}</span>
          {value === option && (
            <Check className="w-5 h-5 text-primary" />
          )}
        </button>
      ))}
    </div>
  );
}

interface RatingScaleProps {
  value: number | null;
  onChange: (value: number) => void;
  max?: number;
}

export function RatingScale({ value, onChange, max = 10 }: RatingScaleProps) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between text-sm text-muted-foreground">
        <span>Not likely</span>
        <span>Very likely</span>
      </div>
      <div className="flex gap-2 flex-wrap justify-center">
        {Array.from({ length: max }, (_, i) => i + 1).map((num) => (
          <button
            key={num}
            onClick={() => onChange(num)}
            className={`w-12 h-12 rounded-xl font-medium text-lg transition-all duration-200
              ${value === num 
                ? "bg-primary text-primary-foreground scale-110 shadow-lg" 
                : "bg-secondary text-foreground hover:bg-primary/10 hover:scale-105"
              }`}
          >
            {num}
          </button>
        ))}
      </div>
    </div>
  );
}

interface TextInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  multiline?: boolean;
}

export function TextInput({ value, onChange, placeholder, multiline }: TextInputProps) {
  const baseClasses = "w-full px-4 py-4 rounded-xl border-2 border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-0 transition-colors text-lg";
  
  if (multiline) {
    return (
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={4}
        className={`${baseClasses} resize-none`}
      />
    );
  }

  return (
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className={baseClasses}
    />
  );
}

interface CheckboxGroupProps {
  options: string[];
  values: string[];
  onChange: (values: string[]) => void;
}

export function CheckboxGroup({ options, values, onChange }: CheckboxGroupProps) {
  const toggleOption = (option: string) => {
    if (values.includes(option)) {
      onChange(values.filter((v) => v !== option));
    } else {
      onChange([...values, option]);
    }
  };

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground mb-4">Select all that apply</p>
      {options.map((option) => (
        <button
          key={option}
          onClick={() => toggleOption(option)}
          className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all duration-200 text-left
            ${values.includes(option) 
              ? "border-primary bg-primary/5" 
              : "border-border hover:border-primary/50 hover:bg-secondary/50"
            }`}
        >
          <span className={`flex items-center justify-center w-6 h-6 rounded-md border-2 transition-colors
            ${values.includes(option) 
              ? "bg-primary border-primary" 
              : "border-muted-foreground"
            }`}>
            {values.includes(option) && (
              <Check className="w-4 h-4 text-primary-foreground" />
            )}
          </span>
          <span className="flex-1 text-foreground font-medium">{option}</span>
        </button>
      ))}
    </div>
  );
}
