"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Send } from "lucide-react";
import { SurveyProgress } from "./survey-progress";
import { MultipleChoice, RatingScale, TextInput, CheckboxGroup } from "./question-types";
import { Button } from "@/components/ui/button";

type QuestionType = "multiple-choice" | "rating" | "text" | "checkbox";

interface Question {
  id: number;
  type: QuestionType;
  question: string;
  description?: string;
  options?: string[];
  placeholder?: string;
  multiline?: boolean;
}

const questions: Question[] = [
  {
    id: 1,
    type: "multiple-choice",
    question: "How did you discover us?",
    description: "We&apos;d love to know what brought you here.",
    options: [
      "Social Media",
      "Search Engine",
      "Word of Mouth",
      "Online Advertisement",
      "News Article",
    ],
  },
  {
    id: 2,
    type: "rating",
    question: "How likely are you to recommend us?",
    description: "On a scale of 1-10, how likely would you recommend our service to a friend or colleague?",
  },
  {
    id: 3,
    type: "checkbox",
    question: "Which features interest you most?",
    description: "Select all the features that caught your attention.",
    options: [
      "Easy to use interface",
      "Fast performance",
      "Beautiful design",
      "Excellent support",
      "Affordable pricing",
      "Advanced analytics",
    ],
  },
  {
    id: 4,
    type: "text",
    question: "What would make us better?",
    description: "Your feedback helps us improve. Share any thoughts or suggestions.",
    placeholder: "Tell us what you think...",
    multiline: true,
  },
  {
    id: 5,
    type: "multiple-choice",
    question: "How often do you use similar products?",
    description: "This helps us understand your experience level.",
    options: [
      "Daily",
      "Weekly",
      "Monthly",
      "Rarely",
      "This is my first time",
    ],
  },
];

type AnswerValue = string | number | string[] | null;

export function SurveyContainer() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [answers, setAnswers] = useState<Record<number, AnswerValue>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [direction, setDirection] = useState<"next" | "prev">("next");

  const currentQuestion = questions[currentStep - 1];
  const totalSteps = questions.length;

  const updateAnswer = (questionId: number, value: AnswerValue) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  };

  const canProceed = () => {
    const answer = answers[currentQuestion.id];
    if (answer === null || answer === undefined) return false;
    if (Array.isArray(answer) && answer.length === 0) return false;
    if (typeof answer === "string" && answer.trim() === "") return false;
    return true;
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setDirection("next");
      setCurrentStep((prev) => prev + 1);
    } else {
      handleSubmit();
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setDirection("prev");
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleSubmit = () => {
    console.log("[v0] Survey submitted:", answers);
    setIsSubmitted(true);
    // Redirect to reward page after a brief moment
    setTimeout(() => {
      router.push("/reward");
    }, 500);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="max-w-lg text-center space-y-6">
          <div className="w-20 h-20 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
            <Sparkles className="w-10 h-10 text-primary" />
          </div>
          <h1 className="font-serif text-4xl md:text-5xl text-foreground text-balance">
            Thank you for your feedback!
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Your responses have been recorded. We truly appreciate you taking the time to help us improve.
          </p>
          <Button
            onClick={() => {
              setIsSubmitted(false);
              setCurrentStep(1);
              setAnswers({});
            }}
            variant="outline"
            className="mt-6"
          >
            Take another survey
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-3xl mx-auto px-6 py-4">
          <SurveyProgress currentStep={currentStep} totalSteps={totalSteps} />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-6">
        <div
          key={currentQuestion.id}
          className={`w-full max-w-2xl space-y-8 animate-in fade-in duration-300 ${
            direction === "next" ? "slide-in-from-right-4" : "slide-in-from-left-4"
          }`}
        >
          {/* Question Number Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-secondary rounded-full">
            <span className="text-sm font-medium text-muted-foreground">
              Question {currentStep}
            </span>
          </div>

          {/* Question */}
          <div className="space-y-3">
            <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-foreground text-balance leading-tight">
              {currentQuestion.question}
            </h2>
            {currentQuestion.description && (
              <p className="text-lg text-muted-foreground leading-relaxed">
                {currentQuestion.description}
              </p>
            )}
          </div>

          {/* Answer Input */}
          <div className="pt-4">
            {currentQuestion.type === "multiple-choice" && (
              <MultipleChoice
                options={currentQuestion.options || []}
                value={answers[currentQuestion.id] as string | null}
                onChange={(value) => updateAnswer(currentQuestion.id, value)}
              />
            )}

            {currentQuestion.type === "rating" && (
              <RatingScale
                value={answers[currentQuestion.id] as number | null}
                onChange={(value) => updateAnswer(currentQuestion.id, value)}
              />
            )}

            {currentQuestion.type === "text" && (
              <TextInput
                value={(answers[currentQuestion.id] as string) || ""}
                onChange={(value) => updateAnswer(currentQuestion.id, value)}
                placeholder={currentQuestion.placeholder}
                multiline={currentQuestion.multiline}
              />
            )}

            {currentQuestion.type === "checkbox" && (
              <CheckboxGroup
                options={currentQuestion.options || []}
                values={(answers[currentQuestion.id] as string[]) || []}
                onChange={(values) => updateAnswer(currentQuestion.id, values)}
              />
            )}
          </div>
        </div>
      </main>

      {/* Footer Navigation */}
      <footer className="sticky bottom-0 bg-background/80 backdrop-blur-md border-t border-border">
        <div className="max-w-3xl mx-auto px-6 py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={handlePrev}
            disabled={currentStep === 1}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Previous
          </Button>

          <div className="flex items-center gap-2">
            {questions.map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  setDirection(index + 1 > currentStep ? "next" : "prev");
                  setCurrentStep(index + 1);
                }}
                className={`w-2 h-2 rounded-full transition-all duration-200
                  ${index + 1 === currentStep 
                    ? "bg-primary w-6" 
                    : answers[index + 1] 
                      ? "bg-primary/50" 
                      : "bg-border"
                  }`}
                aria-label={`Go to question ${index + 1}`}
              />
            ))}
          </div>

          <Button
            onClick={handleNext}
            disabled={!canProceed()}
            className="gap-2"
          >
            {currentStep === totalSteps ? (
              <>
                Submit
                <Send className="w-4 h-4" />
              </>
            ) : (
              <>
                Next
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </Button>
        </div>
      </footer>
    </div>
  );
}
