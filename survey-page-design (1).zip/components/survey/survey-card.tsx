"use client";

import Link from "next/link";
import { Clock, Users, DollarSign, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { SurveyMeta } from "@/lib/surveys";

const categoryColors: Record<string, string> = {
  "Customer Experience": "bg-blue-100 text-blue-700",
  Workplace: "bg-amber-100 text-amber-700",
  Technology: "bg-indigo-100 text-indigo-700",
  Research: "bg-teal-100 text-teal-700",
  Events: "bg-rose-100 text-rose-700",
  Health: "bg-green-100 text-green-700",
  Commerce: "bg-orange-100 text-orange-700",
  Environment: "bg-emerald-100 text-emerald-700",
  Marketing: "bg-pink-100 text-pink-700",
  Fun: "bg-yellow-100 text-yellow-700",
};

export function SurveyCard({ survey }: { survey: SurveyMeta }) {
  return (
    <Link href={`/survey/${survey.id}`}>
      <Card className="group border-border hover:border-primary/40 transition-all duration-300 hover:shadow-lg cursor-pointer h-full">
        <CardContent className="p-6 flex flex-col h-full">
          <div className="flex items-start justify-between gap-3 mb-3">
            <Badge
              variant="secondary"
              className={`text-xs font-medium shrink-0 ${categoryColors[survey.category] || "bg-secondary text-secondary-foreground"}`}
            >
              {survey.category}
            </Badge>
            <div className="flex items-center gap-1 text-green-600 font-semibold text-sm shrink-0">
              <DollarSign className="w-4 h-4" />
              <span>{survey.reward}</span>
            </div>
          </div>

          <h3 className="font-serif text-xl text-foreground mb-2 group-hover:text-primary transition-colors leading-snug text-balance">
            {survey.title}
          </h3>

          <p className="text-sm text-muted-foreground leading-relaxed mb-5 flex-1">
            {survey.description}
          </p>

          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {survey.estimatedTime}
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-3.5 h-3.5" />
                {survey.participants.toLocaleString()}
              </span>
            </div>
            <span className="text-xs font-medium text-primary flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              Start survey
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
