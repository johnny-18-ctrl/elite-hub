"use client";

import { ClipboardList, TrendingUp, DollarSign } from "lucide-react";
import { surveys } from "@/lib/surveys";
import { SurveyCard } from "./survey-card";

export function SurveysListing() {
  const totalRewards = surveys.reduce((sum, s) => sum + s.reward, 0);
  const totalParticipants = surveys.reduce((sum, s) => sum + s.participants, 0);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <header className="border-b border-border bg-card">
        <div className="max-w-6xl mx-auto px-6 py-16 md:py-20">
          <div className="max-w-2xl space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-green-100 text-green-700 rounded-full text-sm font-medium">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              {surveys.length} Active Surveys
            </div>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground leading-tight text-balance">
              Earn rewards by sharing your opinions
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Complete quick surveys and earn up to $10 per survey. Your feedback helps shape products, services, and experiences worldwide.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-6 mt-10 max-w-lg">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <ClipboardList className="w-4 h-4" />
                <span className="text-xs font-medium uppercase tracking-wide">Surveys</span>
              </div>
              <p className="text-2xl font-semibold text-foreground">{surveys.length}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <DollarSign className="w-4 h-4" />
                <span className="text-xs font-medium uppercase tracking-wide">Total</span>
              </div>
              <p className="text-2xl font-semibold text-green-600">${totalRewards}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <TrendingUp className="w-4 h-4" />
                <span className="text-xs font-medium uppercase tracking-wide">Taken</span>
              </div>
              <p className="text-2xl font-semibold text-foreground">{totalParticipants.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Survey Grid */}
      <main className="max-w-6xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="font-serif text-2xl text-foreground">Available Surveys</h2>
          <span className="text-sm text-muted-foreground">Earn $10 each</span>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {surveys.map((survey) => (
            <SurveyCard key={survey.id} survey={survey} />
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <p className="text-sm text-muted-foreground">
            Complete surveys honestly to receive your rewards. All responses are anonymous and confidential.
          </p>
        </div>
      </footer>
    </div>
  );
}
