export interface SurveyMeta {
  id: string;
  title: string;
  description: string;
  reward: number;
  questionsCount: number;
  estimatedTime: string;
  category: string;
  status: "active" | "completed" | "expired";
  participants: number;
}

export interface SurveyQuestion {
  id: number;
  type: "multiple-choice" | "rating" | "text" | "checkbox";
  question: string;
  description?: string;
  options?: string[];
  placeholder?: string;
  multiline?: boolean;
}

export const surveys: SurveyMeta[] = [
  {
    id: "customer-satisfaction",
    title: "Customer Satisfaction (CSAT) & Feedback",
    description: "Help us understand how satisfied you are with our products and services. Your honest feedback drives real improvements.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "3 min",
    category: "Customer Experience",
    status: "active",
    participants: 1243,
  },
  {
    id: "employee-engagement",
    title: "Employee Engagement & Workplace Culture",
    description: "Share your thoughts on workplace culture, team dynamics, and what makes a great work environment.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "4 min",
    category: "Workplace",
    status: "active",
    participants: 876,
  },
  {
    id: "product-ux",
    title: "Product Features & User Experience (UX)",
    description: "Tell us about your experience using digital products. What works, what frustrates, and what you wish existed.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "3 min",
    category: "Technology",
    status: "active",
    participants: 2105,
  },
  {
    id: "audience-demographics",
    title: "Audience Demographics",
    description: "Help us understand our diverse community better. Your demographic insights help us create more inclusive experiences.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "2 min",
    category: "Research",
    status: "active",
    participants: 3421,
  },
  {
    id: "event-feedback",
    title: "Event Feedback & Post-Conference Polling",
    description: "Rate your recent event experience. From speakers to logistics, every detail matters to us.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "3 min",
    category: "Events",
    status: "active",
    participants: 654,
  },
  {
    id: "health-wellness",
    title: "Health, Wellness, & Lifestyle Trends",
    description: "Share your health and wellness habits. Your insights help shape better wellness programs and resources.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "4 min",
    category: "Health",
    status: "active",
    participants: 1897,
  },
  {
    id: "consumer-purchasing",
    title: "Consumer Purchasing Behavior",
    description: "Tell us about your shopping habits and what influences your buying decisions in today's marketplace.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "3 min",
    category: "Commerce",
    status: "active",
    participants: 2634,
  },
  {
    id: "environmental-awareness",
    title: "Environmental Awareness & Sustainability",
    description: "Share your views on environmental issues and sustainable practices. Every voice matters for our planet.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "3 min",
    category: "Environment",
    status: "active",
    participants: 1456,
  },
  {
    id: "brand-perception",
    title: "Brand Awareness & Perception",
    description: "How do you perceive the brands around you? Your perceptions help shape better brand experiences.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "3 min",
    category: "Marketing",
    status: "active",
    participants: 1789,
  },
  {
    id: "fun-icebreaker",
    title: "Fun/Icebreaker Feedback",
    description: "A lighthearted survey to break the ice. Fun questions, interesting insights, and a great way to unwind.",
    reward: 10,
    questionsCount: 5,
    estimatedTime: "2 min",
    category: "Fun",
    status: "active",
    participants: 4102,
  },
];

export const surveyQuestions: Record<string, SurveyQuestion[]> = {
  "customer-satisfaction": [
    { id: 1, type: "rating", question: "How satisfied are you with our overall service?", description: "Rate from 1 (very unsatisfied) to 10 (extremely satisfied)." },
    { id: 2, type: "multiple-choice", question: "How often do you use our product or service?", options: ["Daily", "Weekly", "Monthly", "Rarely", "First time"] },
    { id: 3, type: "checkbox", question: "Which aspects do you value most?", description: "Select all that apply.", options: ["Quality", "Speed", "Customer support", "Pricing", "Reliability", "User interface"] },
    { id: 4, type: "multiple-choice", question: "Would you recommend us to others?", options: ["Definitely yes", "Probably yes", "Not sure", "Probably not", "Definitely not"] },
    { id: 5, type: "text", question: "Any additional feedback for us?", placeholder: "Share your thoughts...", multiline: true },
  ],
  "employee-engagement": [
    { id: 1, type: "rating", question: "How engaged do you feel at your workplace?", description: "Rate your level of engagement from 1 to 10." },
    { id: 2, type: "multiple-choice", question: "What best describes your work arrangement?", options: ["Fully remote", "Hybrid", "Fully in-office", "Freelance", "Self-employed"] },
    { id: 3, type: "checkbox", question: "What workplace benefits matter most to you?", description: "Select all that apply.", options: ["Flexible hours", "Health insurance", "Professional development", "Remote work", "Team events", "Mental health support"] },
    { id: 4, type: "multiple-choice", question: "How would you describe your team culture?", options: ["Collaborative", "Competitive", "Relaxed", "Structured", "Innovative"] },
    { id: 5, type: "text", question: "What would improve your workplace experience?", placeholder: "Your suggestions matter...", multiline: true },
  ],
  "product-ux": [
    { id: 1, type: "rating", question: "How intuitive do you find our product interface?", description: "1 being very confusing, 10 being extremely intuitive." },
    { id: 2, type: "multiple-choice", question: "Which device do you primarily use?", options: ["Smartphone", "Tablet", "Laptop", "Desktop", "Multiple devices"] },
    { id: 3, type: "checkbox", question: "Which features do you use most?", description: "Select all that apply.", options: ["Dashboard", "Notifications", "Search", "Settings", "Reports", "Integrations"] },
    { id: 4, type: "multiple-choice", question: "How often do you encounter bugs or issues?", options: ["Never", "Rarely", "Sometimes", "Often", "Very frequently"] },
    { id: 5, type: "text", question: "What feature would you love to see added?", placeholder: "Dream feature...", multiline: true },
  ],
  "audience-demographics": [
    { id: 1, type: "multiple-choice", question: "What is your age range?", options: ["18-24", "25-34", "35-44", "45-54", "55+"] },
    { id: 2, type: "multiple-choice", question: "What is your highest level of education?", options: ["High school", "Some college", "Bachelor's degree", "Master's degree", "Doctorate"] },
    { id: 3, type: "multiple-choice", question: "Which industry do you work in?", options: ["Technology", "Healthcare", "Education", "Finance", "Other"] },
    { id: 4, type: "checkbox", question: "How do you prefer to consume content?", description: "Select all that apply.", options: ["Social media", "Blogs/articles", "Podcasts", "Video content", "Newsletters", "Books"] },
    { id: 5, type: "multiple-choice", question: "What is your primary language?", options: ["English", "Spanish", "French", "Swahili", "Other"] },
  ],
  "event-feedback": [
    { id: 1, type: "rating", question: "How would you rate the overall event experience?", description: "1 being poor, 10 being outstanding." },
    { id: 2, type: "multiple-choice", question: "How did you hear about this event?", options: ["Social media", "Email invitation", "Word of mouth", "Company website", "Advertisement"] },
    { id: 3, type: "checkbox", question: "Which aspects of the event stood out?", description: "Select all that apply.", options: ["Speakers", "Networking", "Venue", "Food & drinks", "Content quality", "Organization"] },
    { id: 4, type: "multiple-choice", question: "Would you attend a similar event in the future?", options: ["Definitely", "Probably", "Maybe", "Unlikely", "No"] },
    { id: 5, type: "text", question: "What improvements would you suggest for future events?", placeholder: "Your feedback shapes our events...", multiline: true },
  ],
  "health-wellness": [
    { id: 1, type: "multiple-choice", question: "How would you describe your overall health?", options: ["Excellent", "Very good", "Good", "Fair", "Poor"] },
    { id: 2, type: "checkbox", question: "Which wellness activities do you practice?", description: "Select all that apply.", options: ["Exercise", "Meditation", "Healthy eating", "Yoga", "Journaling", "Adequate sleep"] },
    { id: 3, type: "rating", question: "How stressed are you on a daily basis?", description: "1 being very relaxed, 10 being extremely stressed." },
    { id: 4, type: "multiple-choice", question: "How many hours of sleep do you get per night?", options: ["Less than 5", "5-6 hours", "7-8 hours", "9+ hours", "It varies"] },
    { id: 5, type: "text", question: "What is your top health goal right now?", placeholder: "Share your wellness goals...", multiline: true },
  ],
  "consumer-purchasing": [
    { id: 1, type: "multiple-choice", question: "Where do you prefer to shop?", options: ["Online only", "In-store only", "Both equally", "Depends on the product", "Marketplace apps"] },
    { id: 2, type: "checkbox", question: "What influences your purchasing decisions?", description: "Select all that apply.", options: ["Price", "Brand reputation", "Reviews", "Recommendations", "Advertising", "Sustainability"] },
    { id: 3, type: "rating", question: "How important are online reviews to you?", description: "1 being not important, 10 being extremely important." },
    { id: 4, type: "multiple-choice", question: "How often do you make impulse purchases?", options: ["Very often", "Sometimes", "Rarely", "Never", "Only during sales"] },
    { id: 5, type: "text", question: "What product category do you spend the most on?", placeholder: "Tell us about your spending...", multiline: true },
  ],
  "environmental-awareness": [
    { id: 1, type: "rating", question: "How concerned are you about climate change?", description: "1 being not concerned, 10 being extremely concerned." },
    { id: 2, type: "checkbox", question: "Which sustainable practices do you follow?", description: "Select all that apply.", options: ["Recycling", "Reducing plastic use", "Using public transport", "Buying local products", "Energy conservation", "Composting"] },
    { id: 3, type: "multiple-choice", question: "Would you pay more for eco-friendly products?", options: ["Yes, always", "Sometimes", "Only if affordable", "Rarely", "No"] },
    { id: 4, type: "multiple-choice", question: "How do you learn about environmental issues?", options: ["Social media", "News outlets", "Documentaries", "School/University", "Community groups"] },
    { id: 5, type: "text", question: "What environmental change would you like to see in your community?", placeholder: "Your vision for a greener future...", multiline: true },
  ],
  "brand-perception": [
    { id: 1, type: "multiple-choice", question: "How do you typically discover new brands?", options: ["Social media", "Word of mouth", "Online ads", "Influencers", "In-store browsing"] },
    { id: 2, type: "rating", question: "How important is brand loyalty to you?", description: "1 being not important, 10 being very important." },
    { id: 3, type: "checkbox", question: "What makes a brand stand out to you?", description: "Select all that apply.", options: ["Quality products", "Good customer service", "Social responsibility", "Innovation", "Affordable pricing", "Strong visual identity"] },
    { id: 4, type: "multiple-choice", question: "How likely are you to switch brands for a better price?", options: ["Very likely", "Somewhat likely", "Neutral", "Unlikely", "Very unlikely"] },
    { id: 5, type: "text", question: "Which brand do you admire most and why?", placeholder: "Tell us about your favorite brand...", multiline: true },
  ],
  "fun-icebreaker": [
    { id: 1, type: "multiple-choice", question: "If you could have any superpower, what would it be?", options: ["Flight", "Invisibility", "Time travel", "Telekinesis", "Mind reading"] },
    { id: 2, type: "multiple-choice", question: "What is your ideal weekend activity?", options: ["Outdoor adventure", "Movie marathon", "Cooking/baking", "Gaming", "Reading a book"] },
    { id: 3, type: "rating", question: "How adventurous are you on a scale of 1-10?", description: "1 being a homebody, 10 being an extreme adventurer." },
    { id: 4, type: "checkbox", question: "Which of these have you tried?", description: "Select all that apply.", options: ["Skydiving", "Scuba diving", "Bungee jumping", "Rock climbing", "Surfing", "Paragliding"] },
    { id: 5, type: "text", question: "What is the most interesting fact about you?", placeholder: "Share something fun...", multiline: true },
  ],
};
